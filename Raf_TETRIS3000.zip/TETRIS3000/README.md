![screenshot](https://raw.githubusercontent.com/adrienmalin/TETRIS3000/master/web/screenshot.png "Screenshot")

[Downloads](https://github.com/adrienmalin/TETRIS3000/releases)

[Play in browser](https://adrienmalin.github.io/TETRIS3000/web/TETRIS3000.html) (Firefox recommanded)

